/**
 * Created by nguyentiendat on 7/22/2015.
 */
qx.Class.define("musicmanager.UI", {

    extend : qx.application.Standalone,

    construct : function()
    {
        this.base(arguments);
        var mainLayout = new qx.ui.layout.VBox();
        mainLayout.setSpacing(20);

        // add the main layout to a container widget and to the document root
        var container = new qx.ui.container.Composite(mainLayout);
        container.setPadding(20);
        this.getRoot().add(container, {left:0,top:0});



        // create the first group box
        var box1 = new qx.ui.groupbox.GroupBox("Code Assist", "icon/16/apps/utilities-text-editor.png");
        container.add(box1);

        box1.setLayout(new qx.ui.layout.VBox());
        box1.add(new qx.ui.form.CheckBox("Show debugging content"));
        box1.add(new qx.ui.form.CheckBox("Enable code completion"));
        box1.add(new qx.ui.form.CheckBox("Show debugging console"));
    }

})