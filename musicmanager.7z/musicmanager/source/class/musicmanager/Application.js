/*******************************************************************************
 * 
 * Copyright:
 * 
 * License:
 * 
 * Authors:
 * 
 ******************************************************************************/

/**
 * This is the main application class of your custom application "musicmanager"
 * 
 * @asset(musicmanager/*)
 */
qx.Class.define("musicmanager.Application", {

	extend : qx.application.Standalone,

	members : {
		groupBox : null,
		nameField : null,
		authorField : null,
		addBtn : null,
		deleteBtn : null,
		updateBtn : null,
		table : null,
		id : 0,

		main : function() {
			//this.base(arguments);

			this.groupBox = new musicmanager.UI();
			this.groupBox.show();
			//this.groupBox.open();
			//qx.log.appender.Native;
			//qx.log.appender.Console;
			//this.initLayout();
			////this.resetValue();
			////this.addListener();
			////this.validateData();
			////this.populationData();
		},

		initLayout : function() {
			this.groupBox = new qx.ui.groupbox.GroupBox("Music Manager");

			this.groupBox.setWidth(600);
			var groupLayout = new qx.ui.layout.VBox(20);
			this.groupBox.setLayout(groupLayout);

			var container = new qx.ui.container.Composite(new qx.ui.layout.Grid(3, 2)).set({paddingLeft : 100});
			var layout = container.getLayout();

			layout.setColumnAlign(0, "right", "middle");
			layout.setColumnAlign(1, "left", "middle");

			var nameLabel = new qx.ui.basic.Label(this.tr("Name:")).set({
						marginTop : 5
					});
			this.nameField = new qx.ui.form.TextField().set({
						width : 150,
						marginTop : 5
					});

			var authorLabel = new qx.ui.basic.Label(this.tr("Author:")).set({
						marginTop : 5
					});
			this.authorField = new qx.ui.form.TextField().set({
						width : 150,
						marginTop : 5
					});

			var btnBox = new qx.ui.container.Composite(new qx.ui.layout.HBox(5))
					.set({
								marginTop : 5
							});
			this.addBtn = new qx.ui.form.Button(this.tr("Add"));
			this.deleteBtn = new qx.ui.form.Button(this.tr("Delete"));
			this.updateBtn = new qx.ui.form.Button(this.tr("Update"));

			btnBox.add(this.addBtn);
			btnBox.add(this.deleteBtn);
			btnBox.add(this.updateBtn);

			container.add(nameLabel, {
						row : 0,
						column : 0
					});
			container.add(this.nameField, {
						row : 0,
						column : 1
					});
			container.add(authorLabel, {
						row : 1,
						column : 0
					});
			container.add(this.authorField, {
						row : 1,
						column : 1
					});
			container.add(btnBox, {
						row : 2,
						column : 1
					});

			var tableModel = new qx.ui.table.model.Simple();
			tableModel.setColumns([this.tr("id"), this.tr("Name"), this.tr("Author")]);

			var custom = { tableColumnModel : function(obj) {
					return new qx.ui.table.columnmodel.Resize(obj);
				},
				initiallyHiddenColumns : [0]
			};

			this.table = new qx.ui.table.Table(tableModel, custom);
			this.table.tableModel = tableModel;
			this.table.setColumnVisibilityButtonVisible(false);

			var tcm = this.table.getTableColumnModel();
			tcm.getBehavior().setWidth(1, "40%");
			tcm.getBehavior().setWidth(2, "60%");
            //
			this.groupBox.add(container);
			this.groupBox.add(this.table);
			this.getRoot().add(this.groupBox, {
						left : 350,
						top : 10
					});

		}

		//resetValue : function() {
		//	this.id = 0;
		//	this.nameField.setValue(null);
		//	this.authorField.setValue(null);
		//	this.nameField.setValid(true);
		//	this.authorField.setValid(true);
		//},
        //
		//populationData : function() {
		//	var rpc = new qx.io.remote.Rpc();
		//	rpc.setCrossDomain(false);
		//	rpc.setTimeout(1000);
		//	var host = window.location.host;
		//	var proto = window.location.protocol;
		//	var webURL = proto + "//" + host + "/musicmanager/.qxrpc";
		//	rpc.setUrl(webURL);
		//	rpc.setServiceName("qooxdoo.MusicHandler");
		//	try {
		//		var result = rpc.callSync("showMusic");
		//		var len = result.length;
		//		var rows = [];
		//		for (var i = 0; i < len; i++) {
		//			var obj = result[i];
		//			rows.push([obj.id, obj.name, obj.author]);
		//		}
		//		this.table.tableModel.setData(rows);
		//	} catch (ex) {
		//		alert(ex.message);
		//	}
        //
		//},
        //
		//addListener : function() {
		//	var _this = this;
		//	this.addBtn.addListener("execute", function(e) {
		//				_this.addMusicListener(e);
		//			});
        //
		//	this.deleteBtn.addListener("execute", function(e) {
		//				_this.deleteMusicListener(e);
		//			});
        //
		//	this.updateBtn.addListener("execute", function(e) {
		//				_this.updateMusicListener(e);
		//			});
        //
		//	this.table.addListener("cellTap", function(e) {
		//				var row = e.getRow();
		//				_this.id = _this.table.tableModel.getValue(0, row);
		//				_this.nameField.setValue(_this.table.tableModel
		//						.getValue(1, row));
		//				_this.authorField.setValue(_this.table.tableModel
		//						.getValue(2, row));
		//			});
        //
		//},
        //
		//addMusicListener : function(e) {
		//	if (!this.validateData()) {
		//		return;
		//	}
		//	try {
		//		var rpc = new qx.io.remote.Rpc();
		//		rpc.setCrossDomain(false);
		//		rpc.setTimeout(1000);
		//		var host = window.location.host;
		//		var proto = window.location.protocol;
		//		var webURL = proto + "//" + host + "/musicmanager/.qxrpc";
		//		rpc.setUrl(webURL);
		//		rpc.setServiceName("qooxdoo.MusicHandler");
		//		var result = rpc.callSync("add", this.nameField.getValue(),
		//				this.authorField.getValue());
		//		this.id = result;
		//		this.populationData();
		//		alert(result);
		//	} catch (ex) {
		//		alert(ex.msg);
		//	}
		//},
        //
		//deleteMusicListener : function(e) {
		//	try {
		//		var rpc = new qx.io.remote.Rpc();
		//		rpc.setCrossDomain(false);
		//		rpc.setTimeout(1000);
		//		var host = window.location.host;
		//		var proto = window.location.protocol;
		//		var webURL = proto + "//" + host + "/musicmanager/.qxrpc";
		//		rpc.setUrl(webURL);
		//		rpc.setServiceName("qooxdoo.MusicHandler");
		//		console.log(this.id);
		//		var result = rpc.callSync("delete", this.id);
		//		this.resetValue();
		//		this.populationData();
		//		alert(result);
		//	} catch (ex) {
		//		alert(ex.msg);
		//	}
		//},
        //
		//updateMusicListener : function(e) {
		//	if (!this.validateData()) {
		//		return;
		//	}
		//	try {
		//		var rpc = new qx.io.remote.Rpc();
		//		rpc.setCrossDomain(false);
		//		rpc.setTimeout(1000);
		//		var host = window.location.host;
		//		var proto = window.location.protocol;
		//		var webURL = proto + "//" + host + "/musicmanager/.qxrpc";
		//		rpc.setUrl(webURL);
		//		rpc.setServiceName("qooxdoo.MusicHandler");
		//		var result = rpc.callSync("update", this.id, this.nameField
		//						.getValue(), this.authorField.getValue());
		//		this.populationData();
		//		alert(result);
		//	} catch (ex) {
		//		alert(ex.msg);
		//	}
		//},
        //
		//validateData : function() {
		//	var b = true;
		//	this.nameField.setValid(true);
		//	this.authorField.setValid(true);
		//	var name = this.nameField.getValue();
		//	var author = this.authorField.getValue();
		//	if (name == null || name.trim() == '') {
		//		this.nameField.setInvalidMessage("Name is required");
		//		this.nameField.setValid(false);
		//		b = false;
		//	}
        //
		//	if (author == null || author.trim() == '') {
		//		this.authorField.setInvalidMessage("Author is required");
		//		this.authorField.setValid(false);
		//		b = false;
		//	}
		//	return b;
		//}

	}

});
