/*******************************************************************************
 * 
 * Copyright:
 * 
 * License:
 * 
 * Authors:
 * 
 ******************************************************************************/

qx.Theme.define("musicmanager.theme.Decoration", {
			extend : qx.theme.modern.Decoration,

			decorations : {}
		});