/*******************************************************************************
 * 
 * Copyright:
 * 
 * License:
 * 
 * Authors:
 * 
 ******************************************************************************/

qx.Theme.define("musicmanager.theme.Font", {
			extend : qx.theme.modern.Font,

			fonts : {}
		});