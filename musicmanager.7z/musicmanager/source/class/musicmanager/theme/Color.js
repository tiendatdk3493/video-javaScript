/*******************************************************************************
 * 
 * Copyright:
 * 
 * License:
 * 
 * Authors:
 * 
 ******************************************************************************/

qx.Theme.define("musicmanager.theme.Color", {
			extend : qx.theme.modern.Color,

			colors : {}
		});