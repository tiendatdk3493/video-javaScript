/*******************************************************************************
 * 
 * Copyright:
 * 
 * License:
 * 
 * Authors:
 * 
 ******************************************************************************/

qx.Theme.define("musicmanager.theme.Theme", {
			meta : {
				color : musicmanager.theme.Color,
				decoration : musicmanager.theme.Decoration,
				font : musicmanager.theme.Font,
				icon : qx.theme.icon.Tango,
				appearance : musicmanager.theme.Appearance
			}
		});